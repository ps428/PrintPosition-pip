# Print Position

A cool python package to add the line number and file name in the print statements. This small tool can be very helpful in debugging modularized Python projects.

## How to use?
Just install the package.